//
// Created by yichenghe on 2021/11/13.
//

#pragma once

#include <iostream>
#include <vector>
#include <dirent.h>
#include <cmath>
#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <XmlRpcValue.h>
#include <inference_engine.hpp>
#include <rm_vision/vision_base/processor_interface.h>
#include <dynamic_reconfigure/server.h>
#include <rm_digtialimg_proc/ArmorConfig.h>
#include <rm_digtialimg_proc/PreprocessConfig.h>
#include <rm_digtialimg_proc/DrawConfig.h>
#include <rm_digtialimg_proc/MakedatasetConfig.h>
#include <mutex>
#include <thread>
#include <nodelet/nodelet.h>
#include <pluginlib/class_loader.h>
#include <rm_msgs/TargetDetectionArray.h>
#include <rm_msgs/TargetDetection.h>
#include <rm_msgs/StatusChange.h>
#include "common.h"

using cv::Mat;
using std::vector;
namespace rm_digtialimg_proc
{
class Bar
{
public:
  cv::RotatedRect bar_rect_;
  double length_len_;  /// long side
  double width_len_;   /// short side
  double lw_ratio_;
  cv::Point2f points_[4];
  cv::Point2f center_point_;
  double angle_;  /// the angle between short side of bar and x axis
  double pixel_contained_ratio_;
  ArmorColor color_;
  bool is_clockwise_;
  int used_num_;
  vector<cv::Point> contour_;

  Bar(cv::RotatedRect bar_rect, const vector<cv::Point>& contour, ArmorColor color) : bar_rect_(std::move(bar_rect))
  {
    length_len_ = std::max(bar_rect_.size.width, bar_rect_.size.height);
    width_len_ = std::min(bar_rect_.size.width, bar_rect_.size.height);
    pixel_contained_ratio_ = cv::contourArea(contour) / bar_rect_.size.area();
    lw_ratio_ = length_len_ / width_len_;
    bar_rect_.points(points_);
    center_point_ = bar_rect_.center;
    contour_ = contour;

    if (length_len_ == bar_rect_.size.width)
    {
      angle_ = bar_rect_.angle + 90.0;
      is_clockwise_ = true;
    }
    else
    {
      angle_ = bar_rect_.angle; ////////////////
      is_clockwise_ = false;
    }
    color_ = color;
  };
 };

class Armor
{
public:
  Bar* bar_left_;
  Bar* bar_right_;
  vector<cv::Point2d> bars_4points_;  /// bl, tl, tr, br ; center point
  vector<cv::Point2d> bars_inter_4points_; /// bl, tl, tr, br ; inter point
  vector<cv::Point2d> bars_PCA_4points_;
  float warp_white_ratio_;
  double length;
  double width;
  cv::Point2d center_;
  double lw_rate_;
  int id_;
  double confidence_;
  double negative_confidence_;
  bool is_big_;
  double area_;
  double parallel_dist_;

  Armor(Bar& bar_left, Bar& bat_right)
  {
    bar_left_ = &bar_left;
    bar_right_ = &bat_right;
    getBarsPoints();
    getArmorArea();
    getCenterPoint();
    getParallelDist();
    id_ = 0;
    confidence_ = 0;
  };

  void getBarsPoints()
  {
    if (bar_left_->is_clockwise_)
    {
      bars_4points_.emplace_back((bar_left_->points_[0] + bar_left_->points_[1]) * 0.5);
      bars_4points_.emplace_back((bar_left_->points_[2] + bar_left_->points_[3]) * 0.5);
      bars_inter_4points_.emplace_back(bar_left_->points_[0]);
      bars_inter_4points_.emplace_back(bar_left_->points_[3]);
    }
    else
    {
      bars_4points_.emplace_back((bar_left_->points_[3] + bar_left_->points_[0]) * 0.5);
      bars_4points_.emplace_back((bar_left_->points_[2] + bar_left_->points_[1]) * 0.5);
      bars_inter_4points_.emplace_back(bar_left_->points_[3]);
      bars_inter_4points_.emplace_back(bar_left_->points_[2]);
    }

    if (bar_right_->is_clockwise_)
    {
      bars_4points_.emplace_back((bar_right_->points_[3] + bar_right_->points_[2]) * 0.5);
      bars_4points_.emplace_back((bar_right_->points_[1] + bar_right_->points_[0]) * 0.5);
      bars_inter_4points_.emplace_back(bar_right_->points_[2]);
      bars_inter_4points_.emplace_back(bar_right_->points_[1]);
    }
    else
    {
      bars_4points_.emplace_back((bar_right_->points_[2] + bar_right_->points_[1]) * 0.5);
      bars_4points_.emplace_back((bar_right_->points_[3] + bar_right_->points_[0]) * 0.5);
      bars_inter_4points_.emplace_back(bar_right_->points_[1]);
      bars_inter_4points_.emplace_back(bar_right_->points_[0]);
    }
  };

  void getArmorArea(){
    double len1 = pow(pow(bars_4points_[0].x - bars_4points_[1].x, 2) + pow(bars_4points_[0].y - bars_4points_[1].y, 2), 0.5);
    double len2 = pow(pow(bars_4points_[1].x - bars_4points_[2].x, 2) + pow(bars_4points_[1].y - bars_4points_[2].y, 2), 0.5);
    double len3 = pow(pow(bars_4points_[0].x - bars_4points_[2].x, 2) + pow(bars_4points_[0].y - bars_4points_[2].y, 2), 0.5);
    double len4 = pow(pow(bars_4points_[2].x - bars_4points_[3].x, 2) + pow(bars_4points_[2].y - bars_4points_[3].y, 2), 0.5);
    double len5 = pow(pow(bars_4points_[0].x - bars_4points_[3].x, 2) + pow(bars_4points_[0].y - bars_4points_[3].y, 2), 0.5);

    double half_cir1 = (len1 + len2 + len3) / 2.0;
    double half_cir2 = (len3 + len4 + len5) / 2.0;

    double area1 = pow((half_cir1 * (half_cir1 - len1) * (half_cir1 - len2) * (half_cir1 - len3)), 0.5);
    double area2 = pow((half_cir2 * (half_cir2 - len3) * (half_cir2 - len4) * (half_cir2 - len5)), 0.5);

    area_ = area1 + area2;
  };

  void getCenterPoint(){
      double p1_x = bars_4points_[0].x;
      double p1_y = bars_4points_[0].y;
      double p2_x = bars_4points_[1].x;
      double p2_y = bars_4points_[1].y;
      double p3_x = bars_4points_[2].x;
      double p3_y = bars_4points_[2].y;
      double p4_x = bars_4points_[3].x;
      double p4_y = bars_4points_[3].y;

      double line1_k = (p1_y - p3_y) / (p1_x - p3_x + 0.000000001);
      double line2_k = (p2_y - p4_y) / (p2_x - p4_x + 0.000000001);
      double line1_b = ((p1_y + p3_y) - line1_k * (p1_x + p3_x)) / 2;
      double line2_b = ((p2_y + p4_y) - line2_k * (p2_x + p4_x)) / 2;

      double cross_point_x = (line2_b - line1_b) / (line1_k - line2_k + 0.000000001);
      double cross_point_y = ((line1_k + line2_k) * cross_point_x + line1_b + line2_b) * 0.5;

      center_.x = int(cross_point_x);
      center_.y = int(cross_point_y);
  }

  void getParallelDist(){
      double p1_x = bars_4points_[0].x;
      double p1_y = bars_4points_[0].y;
      double p2_x = bars_4points_[1].x;
      double p2_y = bars_4points_[1].y;
      double p3_x = bars_4points_[2].x;
      double p3_y = bars_4points_[2].y;
      double p4_x = bars_4points_[3].x;
      double p4_y = bars_4points_[3].y;

      double line1_k = (p1_y - p2_y) / (p1_x - p2_x + 0.000000001);
      double line2_k = (p3_y - p4_y) / (p3_x - p4_x + 0.000000001);
      double line1_b = ((p1_y + p2_y) - line1_k * (p1_x + p2_x)) / 2;
      double line2_b = ((p3_y + p4_y) - line2_k * (p3_x + p4_x)) / 2;

      double dist = pow(pow(bar_left_->center_point_.x - bar_right_->center_point_.x, 2) +
                            pow(bar_left_->center_point_.y - bar_right_->center_point_.y, 2),
                        0.5);
      double vertical_dist1 = fabs(line1_k * bar_right_->center_point_.x - bar_right_->center_point_.y + line1_b) /
                              pow(pow(line1_k, 2) + 1, 0.5);
      double parallel_dist1 = pow(pow(dist, 2) - pow(vertical_dist1, 2), 0.5);

      double vertical_dist2 = fabs(line2_k * bar_left_->center_point_.x - bar_left_->center_point_.y + line2_b) /
                              pow(pow(line2_k, 2) + 1, 0.5);
      double parallel_dist2 = pow(pow(dist, 2) - pow(vertical_dist2, 2), 0.5);

      parallel_dist_ = (parallel_dist1 + parallel_dist2) * 0.5;
  }
};

/**
 * @brief
 *
 */
class Processor : public rm_vision::ProcessorInterface, public nodelet::Nodelet
{
public:
  Processor()
  {
  }
  ~Processor() override
  {
    if (this->my_thread_.joinable())
      my_thread_.join();
  }
  void initialize(ros::NodeHandle& nh) override;

  void hsvToBinary();

  void bgrToBinary();

  Mat setElement();

  void imageProcess(cv_bridge::CvImagePtr& cv_image) override;

  ArmorColor getBarColor(const cv::RotatedRect& rect);

  void findBars();

  void paramReconfig() override;
  bool changeStatusCB(rm_msgs::StatusChange::Request& change, rm_msgs::StatusChange::Response& res);
  ros::ServiceServer status_change_srv_;

  bool isValidBar(const Bar& bar);

  bool isValidArmor(Bar& left_bar, Bar& right_bar);

  bool warp(const vector<cv::Point2d>& points, Mat& dst);

  void findArmor() override;

  void armorPrograming(const vector<vector<int>>& armor_programme);

  vector<cv::Point> calcPCAPoints(vector<cv::Point>&pts);

  ///////////////////////////////////////////////////////

  void cnnInfer(Mat & src);

  vector<double> recalibrateScores(const vector<double>& activate_vector);

  template<typename T> std::vector<int> argsort(const std::vector<T>& array);

  vector<double> weibullWscore(const vector<double>& distance, const vector<double>& alpha_weights);

  vector<double> computeDistance(const vector<double>& activate_vector);
  ////////////////////////////////////////////////////////

  Object getObj() override;

  void putObj() override;

  std::mutex obj_locker_;

  ////////////////////////////////////////////////////////

  void draw() override;

  void drawBars(Mat& image);

  void drawArmors(Mat& image);

  void drawArmorsVertexes(Mat& image);

  bool drawWarp();

  void makeDigitalDataset(Armor armor);
  int g_num=0;

  dynamic_reconfigure::Server<ArmorConfig>* armor_cfg_srv_;  // server of dynamic config about armor
  dynamic_reconfigure::Server<PreprocessConfig>*
      preprocess_cfg_srv_;                                 // server of dynamic config about preprocess of image
  dynamic_reconfigure::Server<DrawConfig>* draw_cfg_srv_;  // server of dynamic config about draw image
  dynamic_reconfigure::Server<MakedatasetConfig>* make_dataset_cfg_srv_;
  dynamic_reconfigure::Server<ArmorConfig>::CallbackType armor_cfg_cb_;
  dynamic_reconfigure::Server<PreprocessConfig>::CallbackType preprocess_cfg_cb_;
  dynamic_reconfigure::Server<DrawConfig>::CallbackType draw_cfg_cb_;
  dynamic_reconfigure::Server<MakedatasetConfig>::CallbackType make_dataset_cfg_cb_;

  void armorconfigCB(ArmorConfig& config, uint32_t level);
  bool armor_dynamic_reconfig_initialized_ = false;

  void drawconfigCB(DrawConfig& config, uint32_t level);

  void preProcessconfigCB(PreprocessConfig& config, uint32_t level);
  bool pre_process_dynamic_reconfig_initialized_ = false;

  void datasetconfigCB(MakedatasetConfig& config, uint32_t level );

  void onInit() override;
private:
  rm_msgs::TargetDetectionArray target_array_;
  ros::Publisher target_pub_;
  ros::NodeHandle nh_;
  std::shared_ptr<image_transport::ImageTransport> it_;
  image_transport::CameraSubscriber cam_sub_;
  void callback(const sensor_msgs::ImageConstPtr& img, const sensor_msgs::CameraInfoConstPtr& info)
  {
    target_array_.header = info->header;
    boost::shared_ptr<cv_bridge::CvImage> temp = boost::const_pointer_cast<cv_bridge::CvImage>(cv_bridge::toCvShare(img, "bgr8"));
    imageProcess(temp);
    findArmor();
    draw();
    for (auto& target : target_array_.detections)
    {
      target.pose.position.x = info->roi.x_offset;
      target.pose.position.y = info->roi.y_offset;
    }
    // if (!target_array_.detections.empty())
    target_pub_.publish(target_array_);
  }
  cv::Mat_<uchar> resizeAndPadding(cv::Mat& src);

  std::thread my_thread_;
  image_transport::Publisher image_pub_;

  int preprocess_method_{};
  int target_is_red_{};
  bool is_bar_debug_{};
  bool is_armor_debug_{};
  bool is_classfy_debug_{};

  /// HSV
  int red_h_min_low_{};
  int red_h_max_low_{};
  int red_h_min_high_{};
  int red_h_max_high_{};
  int red_s_min_{};
  int red_s_max_{};
  int red_v_min_{};
  int red_v_max_{};
  int blue_h_min_{};
  int blue_h_max_{};
  int blue_s_min_{};
  int blue_s_max_{};
  int blue_v_min_{};
  int blue_v_max_{};

  /// RGB(single channel)
  int binary_thresh_{};

  /// morphology
  int morph_type_{};
  int binary_element_{};

  /// bar morphology
  vector<vector<cv::Point>> contours_{};

  /// bar compute
  //int bar_br_thresh_{};
  int select_bar_{};
  int max_angle_{};
  float max_lw_ratio_{};
  float min_lw_ratio_{};
  double min_pixel_contained_ratio_{};
  double max_bars_ratio_{};

  /// armor compute
  double min_bars_distance_{};
  double max_bars_distance_{};
  double max_bars_angle_{};
  double max_bars_y_dis_{};
  float warp_white_ratio_{};
  bool select_by_last_{};

  /// armor warp
  vector<cv::Point2d>warp_reference_;
  bool gamma_{};
  double contrast_alpha_{};
  double contrast_beta_{};
  double gamma_y_{};
  int warp_thresh_{};
  bool rotate_{};

  /// id classification
  std::string xml_path_{};
  std::string bin_path_{};
  InferenceEngine::ExecutableNetwork network_{};
  InferenceEngine::CNNNetwork cnn_network_{};
  InferenceEngine::InferRequest infer_request_{};
  std::string input_name_{};
  InferenceEngine::OutputsDataMap output_info_{};
  std::pair<int, float> result_{};
  double negative_confidence_{};
  std::vector<double> expand_ratio_{};
  float id_confidence_{};
  std::vector<int> input_shape_{};
  bool use_id_cls_{};
  float min_id_white_ratio_{};
  float max_id_white_ratio_{};
  double firstnet_score_;
  vector<double> softmax_score_;
  /// weibull model
  std::vector<std::vector<double>> weibull_model_{};
  std::vector<std::vector<double>> weibull_mean_{};

  /// draw
  DrawImage draw_type_{};
  int line_width_{};

  vector<Bar> bars_{};
  vector<Armor> armors_{};
  vector<Armor> last_frame_armors_{};

  vector<vector<cv::Point2d>> points_{};
  vector<int> labels_{};
  vector<float> probs_{};
  Object object_{};

  Mat raw_image_{};
  Mat binary_image_{};
  Mat morpro_image_{};
  Mat warp_image_{};
  /// make dataset
  bool make_dataset_{};  ////////////////////
  bool collected_completely_ = false;
  int image_num_{};
  int image_index_ = 0;  // range 0~image_num_ * 9
  int image_id_{};       /////////////////
  bool dataset_split_{};
  bool continute_{};
  std::string dataset_path_{};
  std::map<int, std::pair<int, std::string>> last_img_index_{};  // (image_id, (last img index, last img path))
};

}  // namespace rm_digtialimg_proc
